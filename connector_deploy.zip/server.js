require("dotenv").config();

const express = require("express");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const path = require("path");
let jwt = null;
try {
  jwt = require("jsonwebtoken");
} catch (_) {
  // Optional dependency; tenant verification will be disabled if missing.
}

const app = express();
app.use(express.json({ limit: "2mb" }));

const PORT = process.env.PORT || 8080;
const API_KEY = process.env.API_KEY || "change-me";
const EVOLVESA_BASE_URL = (process.env.EVOLVESA_BASE_URL || "").trim().replace(/\/$/, "");
const EVOLVESA_API_KEY = (process.env.EVOLVESA_API_KEY || "").trim();
const EVOLVESA_TIMEOUT_MS = Number(process.env.EVOLVESA_TIMEOUT_MS || 15000);
const EVOLVESA_STOCK_ENDPOINT = (process.env.EVOLVESA_STOCK_ENDPOINT || "/api/v1/stocks").trim();
const EVOLVESA_LEAD_TRIGGER_URL = (process.env.EVOLVESA_LEAD_TRIGGER_URL || "").trim();
const EVOLVESA_LEAD_RECEIVING_ENTITY_ID = (process.env.EVOLVESA_LEAD_RECEIVING_ENTITY_ID || "505").trim();
const EVOLVESA_LEAD_RECEIVING_ENTITY_NAME = (process.env.EVOLVESA_LEAD_RECEIVING_ENTITY_NAME || "LDC").trim();
const EVOLVESA_DEFAULT_LEAD_ANCILLARY_AREA = (process.env.EVOLVESA_DEFAULT_LEAD_ANCILLARY_AREA || "Gauteng").trim();
const EVOLVESA_DEFAULT_LEAD_USER_AREA = (process.env.EVOLVESA_DEFAULT_LEAD_USER_AREA || "JHB").trim();
const AUTOTRADER_LISTINGS_URL = (
  process.env.AUTOTRADER_LISTINGS_URL ||
  "https://services.autotrader.co.za/api/syndication/v1.0/listings"
).trim();
const AUTOTRADER_BASIC_AUTH = (process.env.AUTOTRADER_BASIC_AUTH || "").trim();
const AUTOTRADER_TIMEOUT_MS = Number(process.env.AUTOTRADER_TIMEOUT_MS || 12000);
const AUTH_JWT_SECRET = (process.env.AUTH_JWT_SECRET || "").trim();
const COMMAND_MAX_RETRIES = Number(process.env.COMMAND_MAX_RETRIES || 3);
const COMMAND_RETRY_DELAY_MS = Number(process.env.COMMAND_RETRY_DELAY_MS || 1200);
const CONNECTOR_DATA_DIR = process.env.CONNECTOR_DATA_DIR || path.join(__dirname, "data");
const STORE_FILE = path.join(CONNECTOR_DATA_DIR, "commands-store.json");

if (!API_KEY || API_KEY === "change-me") {
  throw new Error("Refusing to start: set a strong API_KEY in connector .env (not 'change-me').");
}

function log(level, message, ctx = {}) {
  const payload = {
    ts: new Date().toISOString(),
    level,
    message,
    ...ctx,
  };
  // Keep logs machine-readable for production aggregation.
  console.log(JSON.stringify(payload));
}

function safeSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function mapTruTradeError(err) {
  const raw = (err && (err.message || String(err))) || "Unknown Tru-Trade error";
  const lower = raw.toLowerCase();
  if (lower.includes("invalid model information")) {
    const suggestions = Array.isArray(err?.modelSuggestions) ? err.modelSuggestions : [];
    const suggestedText = suggestions.length > 0 ? ` Suggested models: ${suggestions.slice(0, 8).join(", ")}` : "";
    return {
      httpStatus: 422,
      userMessage: "Tru-Trade does not recognize this model. Edit make/model to match Tru-Trade naming, then retry.",
      error: raw,
      hint: `Use exact Tru-Trade model text (catalog value, not free-text from barcode).${suggestedText}`,
      suggestions,
    };
  }
  if (lower.includes("invalid variant information")) {
    const suggestions = Array.isArray(err?.variantSuggestions) ? err.variantSuggestions : [];
    const suggestedText = suggestions.length > 0 ? ` Suggested variants: ${suggestions.slice(0, 8).join(", ")}` : "";
    return {
      httpStatus: 422,
      userMessage: "Tru-Trade does not recognize this variant. Edit variant to the exact Tru-Trade catalog name, then retry.",
      error: raw,
      hint: `Variant names are strict; shorter/base variant names usually work better.${suggestedText}`,
      suggestions,
    };
  }
  if (lower.includes("tru-trade http 401") || lower.includes("tru-trade http 403")) {
    return {
      httpStatus: 502,
      userMessage: "Tru-Trade credentials were rejected. Check connector .env credentials and restart connector.",
      error: raw,
    };
  }
  return {
    httpStatus: 500,
    userMessage: raw,
    error: raw,
  };
}

function evolveAuthHeaderValue() {
  if (!EVOLVESA_API_KEY) return null;
  const v = String(EVOLVESA_API_KEY).trim();
  if (!v) return null;
  if (/^Bearer\s+/i.test(v)) return v;
  return `Bearer ${v}`;
}

function truTradeBasicAuthHeaderValue() {
  const u = process.env.TRUTRADE_AUTH_USERNAME;
  const p = process.env.TRUTRADE_AUTH_PASSWORD;
  if (u && p) {
    return `Basic ${Buffer.from(`${u}:${p}`).toString("base64")}`;
  }
  const apiKey = process.env.TRUTRADE_API_KEY;
  const apiSecret = process.env.TRUTRADE_API_SECRET;
  if (!apiKey || !apiSecret) return null;
  return `Basic ${Buffer.from(`${apiKey}:${apiSecret}`).toString("base64")}`;
}

function autoTraderAuthHeaderValue() {
  const token = AUTOTRADER_BASIC_AUTH.trim();
  if (!token) return null;
  return token.startsWith("Basic ") ? token : `Basic ${token}`;
}

function pickFirstHttpImage(urls) {
  const list = Array.isArray(urls) ? urls : [];
  for (const u of list) {
    const s = String(u || "").trim();
    if (s.startsWith("http://") || s.startsWith("https://")) return s;
  }
  return null;
}

function requireAuth(req, res, next) {
  const header = req.headers["authorization"] || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  const token = match ? match[1] : null;
  if (!token || token !== API_KEY) {
    return res.status(401).json({
      error: "unauthorized",
      hint: "Authorization Bearer token must match API_KEY in connector .env (CubeOneScan Settings → API Key).",
    });
  }
  next();
}

function extractTenantContext(req, _res, next) {
    const userToken = String(req.headers["x-user-token"] || "").trim();
    let claims = {};
    if (userToken && AUTH_JWT_SECRET) {
      try {
        claims = jwt.verify(userToken, AUTH_JWT_SECRET);
      } catch (_) {
        claims = {};
      }
    }
    req.tenantContext = {
      userId: claims.userId || null,
      userEmail: claims.email || null,
      dealerId: claims.dealerId || req.headers["x-dealer-id"] || null,
      branchId: claims.branchId || req.headers["x-branch-id"] || null,
      role: claims.role || null,
    };
    next();
}

const BUSINESS_ROLES = ["dealer_principal", "sales_manager", "sales_person"];
const REQUEST_TO_COMMAND = {
  TRADE_IN_REQUEST: "TRADE_IN",
  STOCK_TAKE_REQUEST: "STOCK_TAKE",
};

function normalizeRole(rawRole) {
  const role = String(rawRole || "").trim().toLowerCase();
  if (BUSINESS_ROLES.includes(role)) return role;
  if (["admin", "owner", "superadmin"].includes(role)) return "dealer_principal";
  if (role === "agent") return "sales_person";
  return "sales_person";
}

function canSubmitCommand(role, commandType) {
  const r = normalizeRole(role);
  if (commandType === "SEND_STOCK_TO_LEAD") return true;
  if (r === "dealer_principal") return true;
  if (r === "sales_manager") {
    return [
      "CREATE_LEAD",
      "SHARE_LEAD",
      "TRUTRADE_REPORT",
      "CREATE_STOCK_UNIT",
      "SEND_STOCK_TO_LEAD",
      "TRADE_IN",
      "STOCK_TAKE",
    ].includes(commandType);
  }
  // sales_person
  return [
    "CREATE_LEAD",
    "SHARE_LEAD",
    "TRUTRADE_REPORT",
    "CREATE_STOCK_UNIT",
    "SEND_STOCK_TO_LEAD",
    "TRADE_IN",
    "STOCK_TAKE",
    "TRADE_IN_REQUEST",
    "STOCK_TAKE_REQUEST",
  ].includes(commandType);
}

function requiresManagerApproval(role, commandType) {
  const r = normalizeRole(role);
  return r === "sales_person" && (commandType === "TRADE_IN" || commandType === "STOCK_TAKE");
}

function isManagerOrPrincipal(role) {
  const r = normalizeRole(role);
  return r === "dealer_principal" || r === "sales_manager";
}

/**
 * In-memory command queue.
 * Replace with a database later; for v1 it's good enough to validate the flow end-to-end.
 */
const commands = new Map(); // correlationId -> { status, createdAt, commandType, payload, result }
const idempotencyIndex = new Map(); // idempotencyKey -> correlationId
const deadLetters = [];

function ensureDataDir() {
  if (!fs.existsSync(CONNECTOR_DATA_DIR)) {
    fs.mkdirSync(CONNECTOR_DATA_DIR, { recursive: true });
  }
}

function persistStore() {
  ensureDataDir();
  const store = {
    version: 1,
    savedAt: new Date().toISOString(),
    commands: Array.from(commands.values()),
    idempotencyIndex: Object.fromEntries(idempotencyIndex.entries()),
    deadLetters,
  };
  fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), "utf8");
}

function loadStore() {
  ensureDataDir();
  if (!fs.existsSync(STORE_FILE)) return;
  const raw = fs.readFileSync(STORE_FILE, "utf8");
  if (!raw.trim()) return;
  const parsed = JSON.parse(raw);
  for (const record of parsed.commands || []) {
    if (record?.correlationId) {
      commands.set(record.correlationId, record);
    }
  }
  for (const [k, v] of Object.entries(parsed.idempotencyIndex || {})) {
    if (k && v) idempotencyIndex.set(k, v);
  }
  for (const d of parsed.deadLetters || []) {
    deadLetters.push(d);
  }
}

function normalizeCommandBody(body) {
  const commandType = body?.commandType;
  if (typeof commandType !== "string" || commandType.trim().length === 0) {
    return { error: "commandType is required" };
  }

  const correlationId = typeof body?.correlationId === "string" && body.correlationId.trim().length > 0
    ? body.correlationId.trim()
    : `scan_${uuidv4()}`;

  return {
    commandType: commandType.trim(),
    correlationId,
    payload: body?.payload ?? {},
    meta: body?.meta ?? {},
  };
}

function createOrUpdateCommand(record) {
  commands.set(record.correlationId, record);
  if (record.idempotencyKey && record.commandType === "CREATE_LEAD") {
    idempotencyIndex.set(record.idempotencyKey, record.correlationId);
  }
  persistStore();
}

function pushDeadLetter(record, errorMessage) {
  deadLetters.push({
    deadLetterId: `dlq_${uuidv4()}`,
    failedAt: new Date().toISOString(),
    correlationId: record.correlationId,
    commandType: record.commandType,
    payload: record.payload,
    attempts: record.attempts || 0,
    error: errorMessage,
  });
  persistStore();
}

function evolveConfigured() {
  return Boolean(EVOLVESA_BASE_URL && EVOLVESA_API_KEY);
}

function toEvolveLeadPayload(payload) {
  const dl = payload?.driverLicense || payload?.lead || {};
  const tenant = payload?._tenantContext || {};
  return {
    firstName: dl.NAMES || dl.firstName || "",
    lastName: dl.SURNAME || dl.lastName || "",
    idNumber: dl.ID_NUMBER || dl.idNumber || "",
    licenseNumber: dl.LICENSE_NUMBER || dl.licenseNumber || "",
    phone: dl.phone || dl.mobile || payload?.phone || "",
    email: dl.email || payload?.email || "",
    dealerId: tenant.dealerId || "",
    branchId: tenant.branchId || "",
    createdByUserId: tenant.userId || "",
    source: payload?.source || "CubeOneScan",
    raw: payload,
  };
}

function toEvolveStockPayload(payload) {
  const stock = payload?.vehicle || payload?.stock || {};
  const tenant = payload?._tenantContext || {};
  return {
    year: stock.year || stock.firstRegistrationYear || "",
    make: stock.make || "",
    model: stock.model || "",
    variant: stock.variant || "",
    mileage: stock.mileage || "",
    price: stock.price || "",
    colour: stock.color || stock.colour || "",
    vinNumber: stock.vin || "",
    licensePlate: stock.registration || stock.licenceNumber || "",
    category: stock.category || "",
    notes: stock.notes || "",
    engineNumber: stock.engineNumber || "",
    expiryDate: stock.expiry || "",
    firstRegistrationDate: stock.firstRegistrationDate || "",
    firstRegistrationYear: stock.firstRegistrationYear || "",
    dealerId: tenant.dealerId || "",
    branchId: tenant.branchId || "",
    createdByUserId: tenant.userId || "",
    source: payload?.source || "CubeOneScan",
    raw: payload,
  };
}

function formatEvolvesaLocalDateTime(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const HH = String(d.getHours()).padStart(2, "0");
  const MM = String(d.getMinutes()).padStart(2, "0");
  const SS = String(d.getSeconds()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd} ${HH}:${MM}:${SS}`;
}

async function evolvesaTriggerCreateLead(payload) {
  if (!EVOLVESA_LEAD_TRIGGER_URL) {
    throw new Error("EVOLVESA_LEAD_TRIGGER_URL not configured");
  }

  const dl = payload?.driverLicense || payload?.lead || {};
  const tenant = payload?._tenantContext || {};

  const ancillaryArea = dl?.area || payload?.area || EVOLVESA_DEFAULT_LEAD_ANCILLARY_AREA;
  const userArea = payload?.userArea || dl?.userArea || EVOLVESA_DEFAULT_LEAD_USER_AREA;
  const firstName = dl?.firstName || dl?.NAMES || "";
  const lastName = dl?.lastName || dl?.SURNAME || "";
  const fullName = `${firstName} ${lastName}`.trim() || dl?.name || payload?.name || "Customer";

  const phone = dl?.phone || dl?.mobile || payload?.phone || "";
  const email = dl?.email || payload?.email || "";

  // “created/lead-reference” + “receiving-entity” are required by the trigger payload structure.
  const leadReference = dl?.idNumber || dl?.LICENSE_NUMBER || dl?.licenseNumber || `lead_${uuidv4()}`;
  const created = formatEvolvesaLocalDateTime(new Date());

  // Minimal “ancillary-data” keeping payload shape, but excluding vehicle detail as requested.
  const requestBody = {
    "ancillary-data": {
      area: ancillaryArea,
      type: "stock",
    },
    created,
    "lead-reference": String(leadReference),
    "receiving-entity": {
      id: EVOLVESA_LEAD_RECEIVING_ENTITY_ID,
      name: EVOLVESA_LEAD_RECEIVING_ENTITY_NAME,
    },
    "user-data": {
      area: userArea,
      email,
      message:
        dl?.message ||
        payload?.message ||
        `Lead created from CubeOneScan. Dealer=${tenant?.dealerId || ""} Branch=${tenant?.branchId || ""}`,
      "mobile-number": phone,
      name: fullName,
    },
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), EVOLVESA_TIMEOUT_MS);
  try {
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
    };
    const authHeaderValue = evolveAuthHeaderValue();
    if (authHeaderValue) {
      headers.Authorization = authHeaderValue;
    }

    const response = await fetch(EVOLVESA_LEAD_TRIGGER_URL, {
      method: "POST",
      headers,
      body: JSON.stringify(requestBody),
      signal: controller.signal,
    });

    const text = await response.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch (_) {
      json = null;
    }

    if (!response.ok) {
      const preview = text && text.length > 700 ? `${text.slice(0, 700)}…` : text;
      throw new Error(`EvolveSA lead trigger HTTP ${response.status}${preview ? `: ${preview}` : ""}`);
    }

    // Trigger responses vary; try several shapes.
    let leadId = null;
    if (typeof json === "number") leadId = String(json);
    if (Array.isArray(json) && json.length > 0) {
      const first = json[0];
      leadId =
        (typeof first === "number" && String(first)) ||
        first?.leadId ||
        first?.id ||
        null;
    }
    if (!leadId && json && typeof json === "object") {
      leadId = json.leadId || json.id || json.reference || null;
    }

    const resolvedLeadId = leadId || `lead_${uuidv4()}`;
    log("info", "evolvesa_lead_trigger_ok", {
      httpStatus: response.status,
      leadId: resolvedLeadId,
      responseType: json == null ? "empty" : Array.isArray(json) ? "array" : typeof json,
    });

    return {
      mode: "live",
      provider: "EvolveSA",
      leadId: resolvedLeadId,
      rawRef: json?.reference || json?.ref || null,
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function evolvesaCreateLead(payload) {
  if (!EVOLVESA_LEAD_TRIGGER_URL && !evolveConfigured()) {
    return {
      mode: "stub",
      leadId: `lead_${uuidv4()}`,
      warning:
        "EvolveSA not configured. Set EVOLVESA_BASE_URL and EVOLVESA_API_KEY in connector .env.",
      lead: toEvolveLeadPayload(payload),
    };
  }

  // Prefer the trigger URL mapping if configured (matches the Cars.co.za → EvolveSA flow you shared).
  if (EVOLVESA_LEAD_TRIGGER_URL) {
    try {
      return await evolvesaTriggerCreateLead(payload);
    } catch (e) {
      throw e;
    }
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), EVOLVESA_TIMEOUT_MS);
  try {
    const body = toEvolveLeadPayload(payload);
    const response = await fetch(`${EVOLVESA_BASE_URL}/api/v1/leads`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": evolveAuthHeaderValue(),
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch (_) {
      json = null;
    }
    if (!response.ok) {
      const preview = text && text.length > 600 ? `${text.slice(0, 600)}…` : text;
      throw new Error(`EvolveSA HTTP ${response.status}${preview ? `: ${preview}` : ""}`);
    }

    return {
      mode: "live",
      leadId: json?.leadId || json?.id || `lead_${uuidv4()}`,
      provider: "EvolveSA",
      rawRef: json?.reference || json?.ref || null,
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function evolvesaCreateStockUnit(payload) {
  if (!evolveConfigured()) {
    return {
      mode: "stub",
      stockUnitId: `stock_${uuidv4()}`,
      warning:
        "EvolveSA stock integration not configured. Set EVOLVESA_BASE_URL and EVOLVESA_API_KEY in connector .env.",
      stock: toEvolveStockPayload(payload),
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), EVOLVESA_TIMEOUT_MS);
  try {
    const body = toEvolveStockPayload(payload);
    const endpoint = EVOLVESA_STOCK_ENDPOINT.startsWith("/") ? EVOLVESA_STOCK_ENDPOINT : `/${EVOLVESA_STOCK_ENDPOINT}`;
    const response = await fetch(`${EVOLVESA_BASE_URL}${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": evolveAuthHeaderValue(),
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch (_) {
      json = null;
    }
    if (!response.ok) {
      const preview = text && text.length > 600 ? `${text.slice(0, 600)}…` : text;
      throw new Error(`EvolveSA stock HTTP ${response.status}${preview ? `: ${preview}` : ""}`);
    }
    return {
      mode: "live",
      provider: "EvolveSA",
      stockUnitId: json?.stockUnitId || json?.id || `stock_${uuidv4()}`,
      rawRef: json?.reference || json?.ref || null,
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchAutoTraderPhotoForVehicle(vehicle = {}) {
  const authHeader = autoTraderAuthHeaderValue();
  if (!authHeader) return null;

  const needleStock = String(vehicle.stockNumber || vehicle.stockNo || "").trim().toLowerCase();
  const needleReg = String(vehicle.registration || vehicle.registrationNumber || vehicle.licenceNumber || "").trim().toLowerCase();
  if (!needleStock && !needleReg) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), AUTOTRADER_TIMEOUT_MS);
  try {
    const response = await fetch(AUTOTRADER_LISTINGS_URL, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: authHeader,
      },
      signal: controller.signal,
    });
    const text = await response.text();
    if (!response.ok) {
      throw new Error(`AutoTrader listings HTTP ${response.status}${text ? `: ${text.slice(0, 300)}` : ""}`);
    }

    let list = [];
    try {
      const json = text ? JSON.parse(text) : [];
      list = Array.isArray(json) ? json : [];
    } catch (_) {
      return null;
    }

    const hit = list.find((row) => {
      const stockNo = String(row?.stockNumber || "").trim().toLowerCase();
      const regNo = String(row?.registrationNumber || "").trim().toLowerCase();
      if (needleStock && stockNo && stockNo === needleStock) return true;
      if (needleReg && regNo && regNo === needleReg) return true;
      return false;
    });
    if (!hit) return null;
    return pickFirstHttpImage(hit.imageUrls);
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchAutoTraderPhotoForVehicle(vehicle = {}) {
  const authHeader = autoTraderAuthHeaderValue();
  if (!authHeader) return null;

  const needleStock = String(vehicle.stockNumber || vehicle.stockNo || "").trim().toLowerCase();
  const needleReg = String(vehicle.registration || vehicle.registrationNumber || vehicle.licenceNumber || "").trim().toLowerCase();
  if (!needleStock && !needleReg) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), AUTOTRADER_TIMEOUT_MS);
  try {
    const response = await fetch(AUTOTRADER_LISTINGS_URL, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: authHeader,
      },
      signal: controller.signal,
    });
    const text = await response.text();
    if (!response.ok) {
      throw new Error(`AutoTrader listings HTTP ${response.status}${text ? `: ${text.slice(0, 300)}` : ""}`);
    }
    let list = [];
    try {
      const json = text ? JSON.parse(text) : [];
      list = Array.isArray(json) ? json : [];
    } catch (_) {
      return null;
    }

    const hit = list.find((row) => {
      const stockNo = String(row?.stockNumber || "").trim().toLowerCase();
      const regNo = String(row?.registrationNumber || "").trim().toLowerCase();
      if (needleStock && stockNo && stockNo === needleStock) return true;
      if (needleReg && regNo && regNo === needleReg) return true;
      return false;
    });
    if (!hit) return null;
    return pickFirstHttpImage(hit.imageUrls);
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Adapter stubs for each CRM/DMS.
 * For now, we just simulate successful processing.
 */
async function processCommand(commandType, payload) {
  /**
   * v1 stub adapter layer:
   * - Returns synthetic IDs so the mobile workflow can chain commands.
   * - Later we will replace these with real EvolveSA/CMS/Keyloop/VMG adapters.
   */
  const now = new Date().toISOString();

  const getByCorrelation = (correlationId) => {
    if (!correlationId) return null;
    return commands.get(String(correlationId)) || null;
  };

  const resolveLeadId = (payload) => {
    if (payload?.leadId) return payload.leadId;
    const leadCmd = getByCorrelation(payload?.leadCorrelationId);
    return leadCmd?.result?.leadId || null;
  };

  const resolveStockId = (payload) => {
    if (payload?.stockUnitId) return payload.stockUnitId;
    const stockCmd = getByCorrelation(payload?.stockCorrelationId);
    return stockCmd?.result?.stockUnitId || null;
  };

  const result = { processedAt: now };

  function truTradeBasicAuthToken() {
    // Some accounts use portal username/password; API docs use apiKey:apiSecret — support both.
    const u = process.env.TRUTRADE_AUTH_USERNAME;
    const p = process.env.TRUTRADE_AUTH_PASSWORD;
    if (u && p) {
      return Buffer.from(`${u}:${p}`).toString("base64");
    }
    const apiKey = process.env.TRUTRADE_API_KEY;
    const apiSecret = process.env.TRUTRADE_API_SECRET;
    if (!apiKey || !apiSecret) {
      return null;
    }
    return Buffer.from(`${apiKey}:${apiSecret}`).toString("base64");
  }

  async function fetchTruTradeReport(params) {
    const authToken = truTradeBasicAuthToken();
    if (!authToken) {
      throw new Error(
        "Tru-Trade not configured: set TRUTRADE_API_KEY + TRUTRADE_API_SECRET, " +
        "or TRUTRADE_AUTH_USERNAME + TRUTRADE_AUTH_PASSWORD in connector .env, then restart npm start"
      );
    }

    const baseUrl = process.env.TRUTRADE_BASE_URL || "https://api.yourvehiclevalue.co.za/api";
    const { make, model, variant, year, mileage } = params;

    if (!make || !model || !variant || !year || !mileage) {
      throw new Error("Tru-Trade requires make, model, variant, year and mileage");
    }

    const base = baseUrl.replace(/\/$/, "");
    const headers = {
      "Accept": "application/json",
      "Authorization": `Basic ${authToken}`,
    };

    const normalizeKey = (v) => String(v || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const toList = (json) => {
      if (Array.isArray(json)) return json;
      if (Array.isArray(json?.data)) return json.data;
      if (Array.isArray(json?.results)) return json.results;
      if (Array.isArray(json?.items)) return json.items;
      return [];
    };
    const candidateText = (x) => {
      if (x == null) return "";
      if (typeof x === "string" || typeof x === "number") return String(x);
      // Support multiple vendor response shapes (name/label/value, code/year ids, etc.).
      return String(
        x.name ||
        x.label ||
        x.value ||
        x.make ||
        x.model ||
        x.variant ||
        x.year ||
        x.code ||
        x.id ||
        x.description ||
        x.title ||
        ""
      );
    };
    const pickBest = (list, wanted, label) => {
      const w = normalizeKey(wanted);
      const mapped = list.map((x) => ({ raw: x, text: candidateText(x), key: normalizeKey(candidateText(x)) }))
        .filter((x) => x.key.length > 0);
      if (mapped.length === 0) throw new Error(`Tru-Trade lookup returned no ${label} options`);
      const exact = mapped.find((x) => x.key === w);
      if (exact) return exact.text;
      const startsWith = mapped.filter((x) => x.key.startsWith(w) || w.startsWith(x.key));
      if (startsWith.length > 0) {
        startsWith.sort((a, b) => b.key.length - a.key.length);
        return startsWith[0].text;
      }
      const contains = mapped
        .filter((x) => x.key.length >= 3)
        .filter((x) => x.key.includes(w) || w.includes(x.key));
      if (contains.length > 0) {
        contains.sort((a, b) => b.key.length - a.key.length);
        return contains[0].text;
      }
      throw new Error(`Tru-Trade lookup could not match ${label} '${wanted}'`);
    };

    const getJson = async (url) => {
      const response = await fetch(url, { method: "GET", headers });
      const text = await response.text();
      if (process.env.TRUTRADE_DEBUG_LOG === "1") {
        console.error(`[Tru-Trade] GET ${url.replace(/\/\/[^/]+/, "//***")} -> HTTP ${response.status}`);
      }
      let json = null;
      try {
        json = text ? JSON.parse(text) : null;
      } catch (_) {
        json = null;
      }
      if (!response.ok) {
        const preview = text.length > 800 ? text.slice(0, 800) + "…" : text;
        throw new Error(`Tru-Trade HTTP ${response.status}: ${preview}`);
      }
      return json;
    };
    const getJsonSoft = async (url) => {
      try {
        return await getJson(url);
      } catch (_) {
        return null;
      }
    };

    const rawMake = String(make || "").trim();
    const rawModel = String(params.rawModel || model || "").trim();
    const rawVariant = String(params.rawVariant || variant || "").trim();
    let resolvedMake = rawMake;
    let resolvedModel = rawModel;
    let resolvedVariant = rawVariant;
    let resolvedYear = String(year);
    let usedLookupNormalization = false;

    try {
      // Normalize values using Tru-Trade lookup workflow when available.
      const makeList = toList(await getJson(`${base}/lookup/make`));
      resolvedMake = pickBest(makeList, make, "make");

      const modelList = toList(await getJson(`${base}/lookup/model/${encodeURIComponent(resolvedMake)}`));
      resolvedModel = pickBest(modelList, model, "model");

      const yearList = toList(await getJson(`${base}/lookup/year/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(resolvedModel)}`));
      resolvedYear = pickBest(yearList, String(year), "year");

      // Variant lookup endpoint differs by tenant; prefer /lookup/variant and fallback to /lookup/year/.../year.
      let variantJson = await getJsonSoft(
        `${base}/lookup/variant/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(resolvedModel)}/${encodeURIComponent(String(resolvedYear))}`
      );
      if (!variantJson) {
        variantJson = await getJson(
          `${base}/lookup/year/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(resolvedModel)}/${encodeURIComponent(String(resolvedYear))}`
        );
      }
      const variantList = toList(variantJson);
      resolvedVariant = pickBest(variantList, variant, "variant");
      usedLookupNormalization = true;
    } catch (lookupError) {
      // Some Tru-Trade environments do not expose all lookup endpoints.
      // Fall back to direct valuation with best values we already resolved.
      log("warn", "trutrade_lookup_unavailable_fallback_report", {
        error: lookupError?.message || String(lookupError),
        partialResolvedMake: resolvedMake,
        partialResolvedModel: resolvedModel,
      });
      // Keep resolvedMake/resolvedModel if lookup provided them;
      // only variant/year stay as user-provided when those lookups fail.
      resolvedVariant = rawVariant;
      resolvedYear = String(year);
    }

    let fallbackModelCandidates = [];
    if (!usedLookupNormalization) {
      try {
        const modelJson = await getJsonSoft(`${base}/lookup/model/${encodeURIComponent(resolvedMake)}`);
        const modelList = toList(modelJson)
          .map(candidateText)
          .map((x) => String(x || "").trim())
          .filter((x) => x.length > 0);
        const rawNeedle = normalizeKey(rawModel || resolvedModel);
        const words = String(rawModel || resolvedModel)
          .toLowerCase()
          .split(/[^a-z0-9]+/)
          .filter((w) => w.length >= 3);
        const ranked = modelList
          .map((m) => {
            const k = normalizeKey(m);
            const scoreContains = rawNeedle && (k.includes(rawNeedle) || rawNeedle.includes(k)) ? 3 : 0;
            const scoreWords = words.reduce((acc, w) => acc + (k.includes(w) ? 1 : 0), 0);
            return { model: m, score: scoreContains + scoreWords };
          })
          .filter((x) => x.score > 0)
          .sort((a, b) => b.score - a.score || b.model.length - a.model.length)
          .slice(0, 5)
          .map((x) => x.model);
        fallbackModelCandidates = ranked;
      } catch (_) {
        fallbackModelCandidates = [];
      }
    }

    let fallbackVariantCandidates = [];
    if (!usedLookupNormalization) {
      try {
        const modelSet = Array.from(new Set([
          resolvedModel,
          rawModel,
          ...fallbackModelCandidates,
        ].map((x) => String(x || "").trim()).filter((x) => x.length >= 2)));
        const variantSet = new Set();
        for (const m of modelSet.slice(0, 5)) {
          const vJson = await getJsonSoft(
            `${base}/lookup/variant/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(m)}/${encodeURIComponent(String(resolvedYear))}`
          );
          const values = toList(vJson)
            .map(candidateText)
            .map((x) => String(x || "").trim())
            .filter((x) => x.length > 0);
          for (const v of values) variantSet.add(v);
        }
        fallbackVariantCandidates = Array.from(variantSet).slice(0, 12);
      } catch (_) {
        fallbackVariantCandidates = [];
      }
    }

    // Prefer insight endpoint (when lookups worked); keep direct report fallback.
    const valuationEndpoints = usedLookupNormalization
      ? [
          `${base}/insight/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(resolvedModel)}/${encodeURIComponent(resolvedVariant)}/${encodeURIComponent(String(resolvedYear))}`,
          `${base}/report/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(resolvedModel)}/${encodeURIComponent(resolvedVariant)}/${encodeURIComponent(String(resolvedYear))}/${encodeURIComponent(String(mileage))}`,
        ]
      : [
          // Direct mode with heuristic fallbacks for scan-derived strings.
          ...(() => {
            const candidates = [];
            const addCandidate = (m, v) => {
              const key = `${m}|||${v}`;
              if (!m || !v) return;
              if (candidates.some((c) => c.key === key)) return;
              candidates.push({ key, model: m, variant: v });
            };

            const makeText = String(resolvedMake || rawMake).trim();
            const modelText = String(resolvedModel || rawModel).trim();
            const variantText = String(resolvedVariant || rawVariant).trim();
            const rawModelText = rawModel;
            const rawVariantText = rawVariant;
            const makeUpper = makeText.toUpperCase();
            const stripMakePrefix = (value) => {
              const raw = String(value || "").trim();
              if (!raw) return raw;
              const upper = raw.toUpperCase();
              if (upper.startsWith(`${makeUpper} `)) {
                return raw.substring(makeText.length).trim();
              }
              return raw;
            };

            // 1) Normalized/lookup values first.
            addCandidate(modelText, variantText);
            // 1b) Always include raw app values too.
            addCandidate(rawModelText, rawVariantText);
            // 1c) Add likely model candidates from /lookup/model/{make}.
            for (const m of fallbackModelCandidates) {
              addCandidate(m, variantText);
              addCandidate(m, rawVariantText);
            }
            // 1d) If we have catalog variants from lookup, try them too.
            for (const m of [modelText, rawModelText, ...fallbackModelCandidates]) {
              for (const v of fallbackVariantCandidates) {
                addCandidate(m, v);
              }
            }

            // 2) Remove duplicated make prefix from model/variant.
            const modelNoMake = stripMakePrefix(modelText);
            const variantNoMake = stripMakePrefix(variantText);
            const rawModelNoMake = stripMakePrefix(rawModelText);
            const rawVariantNoMake = stripMakePrefix(rawVariantText);
            addCandidate(modelNoMake, variantNoMake);
            addCandidate(rawModelNoMake, rawVariantNoMake);

            // 3) If model and variant are identical full strings, split into model token + variant remainder.
            if (modelNoMake.toUpperCase() === variantNoMake.toUpperCase()) {
              const parts = modelNoMake.split(/\s+/).filter(Boolean);
              if (parts.length >= 2) {
                const modelBase = parts[0];
                const variantRemainder = parts.slice(1).join(" ");
                addCandidate(modelBase, variantRemainder);
              }
            }
            if (rawModelNoMake.toUpperCase() === rawVariantNoMake.toUpperCase()) {
              const parts = rawModelNoMake.split(/\s+/).filter(Boolean);
              if (parts.length >= 2) {
                const modelBase = parts[0];
                const variantRemainder = parts.slice(1).join(" ");
                addCandidate(modelBase, variantRemainder);
              }
            }

            // 4) If variant still starts with model text, drop model from variant.
            if (variantNoMake.toUpperCase().startsWith(`${modelNoMake.toUpperCase()} `)) {
              const compactVariant = variantNoMake.substring(modelNoMake.length).trim();
              addCandidate(modelNoMake, compactVariant);
            }
            if (rawVariantNoMake.toUpperCase().startsWith(`${rawModelNoMake.toUpperCase()} `)) {
              const compactVariant = rawVariantNoMake.substring(rawModelNoMake.length).trim();
              addCandidate(rawModelNoMake, compactVariant);
            }

            // 5) Ignore too-short model tokens from vendor lookup codes in fallback URLs.
            const filtered = candidates.filter((c) => c.model.trim().length >= 2);
            const expanded = [];
            const seen = new Set();
            const addExpanded = (m, v) => {
              const key = `${m}|||${v}`;
              if (seen.has(key)) return;
              seen.add(key);
              expanded.push({ model: m, variant: v });
            };
            for (const c of filtered) {
              addExpanded(c.model, c.variant);
              // Tru-Trade path parameters can choke on "/" inside variants (e.g. A/T).
              if (c.variant.includes("/")) {
                addExpanded(c.model, c.variant.replace(/\//g, " "));
                addExpanded(c.model, c.variant.replace(/\//g, ""));
                addExpanded(c.model, c.variant.replace(/A\/T/gi, "AT"));
                addExpanded(c.model, c.variant.replace(/A\/T/gi, "AUTO"));
              }
            }

            return expanded.flatMap((c) => ([
              `${base}/insight/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(c.model)}/${encodeURIComponent(c.variant)}/${encodeURIComponent(String(resolvedYear))}`,
              `${base}/report/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(c.model)}/${encodeURIComponent(c.variant)}/${encodeURIComponent(String(resolvedYear))}/${encodeURIComponent(String(mileage))}`,
            ]));
          })(),
        ];

    let lastError = null;
    for (const valuationUrl of valuationEndpoints) {
      try {
        const json = await getJson(valuationUrl);
        return {
          ...(json || {}),
          resolvedInput: {
            make: resolvedMake,
            model: resolvedModel,
            variant: resolvedVariant,
            year: String(resolvedYear),
            mileage: String(mileage),
          },
          lookupNormalizationUsed: usedLookupNormalization,
        };
      } catch (e) {
        lastError = e;
      }
    }
    if (lastError) {
      const lower = String(lastError.message || lastError).toLowerCase();
      const uniqueTexts = (list) => {
        const seen = new Set();
        const out = [];
        for (const item of list) {
          const t = String(item || "").trim();
          if (!t) continue;
          const k = t.toLowerCase();
          if (seen.has(k)) continue;
          seen.add(k);
          out.push(t);
        }
        return out;
      };
      const stripMakePrefixGeneric = (makeValue, textValue) => {
        const makeClean = String(makeValue || "").trim();
        const textClean = String(textValue || "").trim();
        if (!makeClean || !textClean) return textClean;
        if (textClean.toUpperCase().startsWith(`${makeClean.toUpperCase()} `)) {
          return textClean.substring(makeClean.length).trim();
        }
        return textClean;
      };

      if (lower.includes("invalid variant information")) {
        const modelCandidates = uniqueTexts([
          resolvedModel,
          rawModel,
          stripMakePrefixGeneric(resolvedMake, resolvedModel),
          stripMakePrefixGeneric(rawMake, rawModel),
        ]).filter((x) => x.length >= 2);

        let variants = [];
        for (const m of modelCandidates) {
          const lookupUrlVariant = `${base}/lookup/variant/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(m)}/${encodeURIComponent(String(resolvedYear))}`;
          const lookupUrlYear = `${base}/lookup/year/${encodeURIComponent(resolvedMake)}/${encodeURIComponent(m)}/${encodeURIComponent(String(resolvedYear))}`;
          let vJson = await getJsonSoft(lookupUrlVariant);
          if (!vJson) vJson = await getJsonSoft(lookupUrlYear);
          const vList = toList(vJson).map(candidateText).map((x) => String(x || "").trim()).filter((x) => x.length > 0);
          if (vList.length > 0) {
            variants = uniqueTexts(vList).slice(0, 12);
            break;
          }
        }
        if (variants.length > 0) {
          lastError.variantSuggestions = variants;
        }
      }

      if (lower.includes("invalid model information")) {
        const modelJson = await getJsonSoft(`${base}/lookup/model/${encodeURIComponent(resolvedMake)}`);
        const modelList = toList(modelJson).map(candidateText).map((x) => String(x || "").trim()).filter((x) => x.length > 0);
        const models = uniqueTexts(modelList).slice(0, 12);
        if (models.length > 0) {
          lastError.modelSuggestions = models;
        }
      }
    }
    throw lastError || new Error("Tru-Trade valuation failed");
  }

  async function sendWhatsAppViaTwilio(opts) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const whatsappFrom = process.env.TWILIO_WHATSAPP_FROM;

    if (!accountSid || !authToken || !whatsappFrom) {
      throw new Error("Twilio not configured (missing TWILIO_ACCOUNT_SID/TWILIO_AUTH_TOKEN/TWILIO_WHATSAPP_FROM)");
    }

    const toRaw = opts?.to;
    if (!toRaw || typeof toRaw !== "string") {
      throw new Error("WhatsApp 'to' number is required");
    }

    const to = toRaw.startsWith("whatsapp:") ? toRaw : `whatsapp:${toRaw}`;
    const from = whatsappFrom.startsWith("whatsapp:") ? whatsappFrom : `whatsapp:${whatsappFrom}`;

    const body = String(opts?.body || "").trim();
    if (!body) throw new Error("WhatsApp 'body' is required");

    const mediaUrl = opts?.mediaUrl ? String(opts.mediaUrl).trim() : null;

    const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
    const form = new URLSearchParams();
    form.append("To", to);
    form.append("From", from);
    form.append("Body", body);
    if (mediaUrl) form.append("MediaUrl", mediaUrl);

    const basicAuth = Buffer.from(`${accountSid}:${authToken}`).toString("base64");

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${basicAuth}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: form
    });

    const text = await response.text();
    if (!response.ok) {
      throw new Error(`Twilio WhatsApp send failed: HTTP ${response.status} ${text}`);
    }

    const json = JSON.parse(text);
    return {
      sid: json.sid,
      status: json.status,
    };
  }

  switch (commandType) {
    case "CREATE_LEAD": {
      const evolve = await evolvesaCreateLead(payload);
      result.leadId = evolve.leadId;
      result.provider = "EvolveSA";
      result.mode = evolve.mode;
      if (evolve.warning) result.warning = evolve.warning;
      if (evolve.rawRef) result.rawRef = evolve.rawRef;
      result.lead = payload?.driverLicense || payload?.lead || {};
      return result;
    }
    case "SHARE_LEAD": {
      const leadId = resolveLeadId(payload);
      if (!leadId) throw new Error("leadId is required (or leadCorrelationId that maps to a CREATE_LEAD)");
      result.leadId = leadId;
      result.shareId = `share_${uuidv4()}`;
      result.shareTarget = payload?.target || payload?.shareTarget || "UNKNOWN";
      return result;
    }
    case "CREATE_STOCK_UNIT": {
      const evolve = await evolvesaCreateStockUnit(payload);
      result.stockUnitId = evolve.stockUnitId;
      result.provider = "EvolveSA";
      result.mode = evolve.mode;
      if (evolve.warning) result.warning = evolve.warning;
      if (evolve.rawRef) result.rawRef = evolve.rawRef;
      result.vehicle = payload?.vehicle || payload?.stock || {};
      return result;
    }
    case "SEND_STOCK_TO_LEAD": {
      const leadId = resolveLeadId(payload);
      const stockUnitId = resolveStockId(payload);
      if (!leadId) throw new Error("leadId is required (or leadCorrelationId)");
      if (!stockUnitId) throw new Error("stockUnitId is required (or stockCorrelationId)");
      result.leadId = leadId;
      result.stockUnitId = stockUnitId;
      result.dispatchId = `dispatch_${uuidv4()}`;
      // Optional: send a WhatsApp message to the lead.
      // Mobile provides recipient number + optional photo URL + optional link.
      const vehicle = payload?.vehicle || payload?.stock || {};
      const reg = vehicle.registration || vehicle.reg || "";
      const make = vehicle.make || "";
      const model = vehicle.model || "";
      const vin = vehicle.vin || "";
      const expiry = vehicle.expiry || "";

      const whatsapp = payload?.whatsapp || {};
      const to = whatsapp?.to || whatsapp?.phone || payload?.whatsappTo;
      let photoUrl = whatsapp?.mediaUrl || whatsapp?.photoUrl || payload?.photoUrl || null;
      if (!photoUrl) {
        try {
          photoUrl = await fetchAutoTraderPhotoForVehicle(vehicle);
          if (photoUrl) {
            result.photoSource = "autotrader_syndication";
            result.photoUrl = photoUrl;
          }
        } catch (e) {
          result.photoLookupWarning = e?.message || String(e);
        }
      }
      const dmsLink = whatsapp?.link || payload?.dmsLink || "";

      if (to) {
        const body =
          `Hi! Your stock unit has been prepared.\n` +
          `Stock ID: ${stockUnitId}\n` +
          (reg ? `Registration: ${reg}\n` : "") +
          (vin ? `VIN: ${vin}\n` : "") +
          (make || model ? `Vehicle: ${make} ${model}\n` : "") +
          (expiry ? `Expiry: ${expiry}\n` : "") +
          (dmsLink ? `View details: ${dmsLink}\n` : "");

        try {
          const twilio = await sendWhatsAppViaTwilio({
            to,
            mediaUrl: photoUrl,
            body,
          });

          result.whatsapp = {
            to,
            messageSid: twilio.sid,
            status: twilio.status,
          };
        } catch (e) {
          result.whatsapp = {
            to,
            skipped: false,
            error: e?.message || String(e),
          };
        }
      } else {
        result.whatsapp = { skipped: true, reason: "no whatsapp.to provided" };
      }

      return result;
    }
    case "TRADE_IN": {
      const stockUnitId = resolveStockId(payload);
      result.stockUnitId = stockUnitId;
      result.tradeInId = `tradein_${uuidv4()}`;
      result.tradeIn = payload || {};
      return result;
    }
    case "STOCK_TAKE": {
      result.stockTakeId = `stocktake_${uuidv4()}`;
      result.stockTake = payload || {};
      return result;
    }
    case "TRUTRADE_REPORT": {
      const make = payload?.make;
      const model = payload?.model;
      const variant = payload?.variant;
      const year = payload?.year;
      const mileage = payload?.mileage;

      const report = await fetchTruTradeReport({ make, model, variant, year, mileage });
      // ReportModel has tradePrice, retailPrice, marketPrice etc.
      result.report = report;
      // Flatten key prices to top-level for convenience
      result.tradePrice = report.tradePrice || report.truetrade_tradePrice || null;
      result.retailPrice = report.retailPrice || report.truetrade_retailPrice || null;
      result.marketPrice = report.marketPrice || report.truetrade_marketPrice || null;
      result.avg_price = report.avg_price || null;
      result.high_price = report.high_price || null;
      result.low_price = report.low_price || null;
      result.avg_mileage = report.avg_mileage || null;
      return result;
    }
    default:
      throw new Error(`Unknown commandType: ${commandType}`);
  }
}

app.get("/healthz", (req, res) => {
  res.json({ ok: true });
});

app.get("/readyz", (req, res) => {
  try {
    ensureDataDir();
    fs.accessSync(CONNECTOR_DATA_DIR, fs.constants.W_OK);
    return res.json({
      ok: true,
      storage: "writable",
      commandsLoaded: commands.size,
      deadLetters: deadLetters.length,
    });
  } catch (e) {
    return res.status(503).json({
      ok: false,
      error: "storage_not_writable",
      detail: e?.message || String(e),
    });
  }
});

app.use((req, res, next) => {
  const requestId = `req_${uuidv4()}`;
  req.requestId = requestId;
  res.setHeader("x-request-id", requestId);
  const started = Date.now();
  res.on("finish", () => {
    log("info", "http_request", {
      requestId,
      method: req.method,
      path: req.originalUrl,
      status: res.statusCode,
      ms: Date.now() - started,
      ip: req.ip,
    });
  });
  next();
});

app.get("/api/v1/trutrade/lookup/:type", requireAuth, async (req, res) => {
  const authHeader = truTradeBasicAuthHeaderValue();
  if (!authHeader) {
    return res.status(503).json({
      error: "trutrade_not_configured",
      hint: "Set TRUTRADE_API_KEY+TRUTRADE_API_SECRET or TRUTRADE_AUTH_USERNAME+TRUTRADE_AUTH_PASSWORD",
    });
  }

  const type = String(req.params.type || "").trim().toLowerCase();
  const make = String(req.query.make || "").trim();
  const model = String(req.query.model || "").trim();
  const year = String(req.query.year || "").trim();
  const base = (process.env.TRUTRADE_BASE_URL || "https://api.yourvehiclevalue.co.za/api").replace(/\/$/, "");

  let upstreamUrl = "";
  if (type === "make") upstreamUrl = `${base}/lookup/make`;
  if (type === "model") {
    if (!make) return res.status(400).json({ error: "make is required for model lookup" });
    upstreamUrl = `${base}/lookup/model/${encodeURIComponent(make)}`;
  }
  if (type === "year") {
    if (!make || !model) return res.status(400).json({ error: "make and model are required for year lookup" });
    upstreamUrl = `${base}/lookup/year/${encodeURIComponent(make)}/${encodeURIComponent(model)}`;
  }
  if (type === "variant") {
    if (!make || !model || !year) return res.status(400).json({ error: "make, model and year are required for variant lookup" });
    upstreamUrl = `${base}/lookup/variant/${encodeURIComponent(make)}/${encodeURIComponent(model)}/${encodeURIComponent(year)}`;
  }
  if (!upstreamUrl) {
    return res.status(400).json({ error: "unsupported lookup type (use: make|model|year|variant)" });
  }

  try {
    const upstream = await fetch(upstreamUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: authHeader,
      },
    });
    const text = await upstream.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch (_) { json = null; }
    if (!upstream.ok) {
      return res.status(upstream.status).json({
        error: "trutrade_lookup_failed",
        type,
        upstreamStatus: upstream.status,
        detail: json || text || null,
      });
    }
    const values = Array.isArray(json) ? json : Array.isArray(json?.value) ? json.value : Array.isArray(json?.data) ? json.data : [];
    return res.json({
      ok: true,
      type,
      make: make || null,
      model: model || null,
      year: year || null,
      values,
      raw: json,
    });
  } catch (e) {
    return res.status(502).json({
      error: "trutrade_lookup_exception",
      type,
      detail: e?.message || String(e),
    });
  }
});

app.get("/api/v1/approvals", requireAuth, extractTenantContext, (req, res) => {
  const role = normalizeRole(req.tenantContext?.role);
  if (!isManagerOrPrincipal(role)) {
    return res.status(403).json({ error: "forbidden", hint: "manager_or_principal_required" });
  }
  const statusFilter = String(req.query.status || "pending").toLowerCase();
  const rows = Array.from(commands.values())
    .filter((c) => Object.keys(REQUEST_TO_COMMAND).includes(String(c.commandType || "")))
    .filter((c) => statusFilter === "all" ? true : String(c.status || "").toLowerCase() === "pending_manager_approval")
    .filter((c) => {
      const dealerOk = !req.tenantContext?.dealerId || !c.tenantContext?.dealerId || c.tenantContext.dealerId === req.tenantContext.dealerId;
      const branchOk = !req.tenantContext?.branchId || !c.tenantContext?.branchId || c.tenantContext.branchId === req.tenantContext.branchId;
      return dealerOk && branchOk;
    })
    .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")))
    .map((c) => ({
      correlationId: c.correlationId,
      status: c.status,
      commandType: c.commandType,
      requestedCommandType: REQUEST_TO_COMMAND[c.commandType] || null,
      createdAt: c.createdAt,
      payload: c.payload,
      tenantContext: c.tenantContext || null,
      error: c.error || null,
    }));
  return res.json({ approvals: rows, count: rows.length });
});

app.post("/api/v1/approvals/:correlationId/approve", requireAuth, extractTenantContext, async (req, res) => {
  const role = normalizeRole(req.tenantContext?.role);
  if (!isManagerOrPrincipal(role)) {
    return res.status(403).json({ error: "forbidden", hint: "manager_or_principal_required" });
  }
  const correlationId = String(req.params.correlationId || "").trim();
  const record = commands.get(correlationId);
  if (!record) return res.status(404).json({ error: "not_found" });
  if (!REQUEST_TO_COMMAND[record.commandType]) return res.status(400).json({ error: "not_approval_request" });
  if (record.status !== "pending_manager_approval") return res.status(409).json({ error: "not_pending", status: record.status });

  const targetType = REQUEST_TO_COMMAND[record.commandType];
  try {
    record.status = "processing";
    record.updatedAt = new Date().toISOString();
    createOrUpdateCommand(record);

    const result = await processCommand(targetType, {
      ...(record.payload || {}),
      _tenantContext: record.tenantContext || null,
      _approval: {
        approvedByUserId: req.tenantContext?.userId || null,
        approvedByRole: role,
        approvedAt: new Date().toISOString(),
      },
    });
    record.status = "done";
    record.updatedAt = new Date().toISOString();
    record.result = {
      approved: true,
      approvedByUserId: req.tenantContext?.userId || null,
      approvedByRole: role,
      executedCommandType: targetType,
      output: result,
    };
    record.error = null;
    createOrUpdateCommand(record);
    return res.json({ ok: true, correlationId, status: record.status, result: record.result });
  } catch (e) {
    record.status = "failed";
    record.updatedAt = new Date().toISOString();
    record.error = e?.message || String(e);
    createOrUpdateCommand(record);
    return res.status(500).json({ error: "approval_execution_failed", detail: record.error });
  }
});

app.post("/api/v1/approvals/:correlationId/reject", requireAuth, extractTenantContext, (req, res) => {
  const role = normalizeRole(req.tenantContext?.role);
  if (!isManagerOrPrincipal(role)) {
    return res.status(403).json({ error: "forbidden", hint: "manager_or_principal_required" });
  }
  const correlationId = String(req.params.correlationId || "").trim();
  const record = commands.get(correlationId);
  if (!record) return res.status(404).json({ error: "not_found" });
  if (!REQUEST_TO_COMMAND[record.commandType]) return res.status(400).json({ error: "not_approval_request" });
  if (record.status !== "pending_manager_approval") return res.status(409).json({ error: "not_pending", status: record.status });

  const reason = String(req.body?.reason || "Rejected by manager").trim();
  record.status = "rejected";
  record.updatedAt = new Date().toISOString();
  record.error = reason;
  record.result = {
    approved: false,
    rejectedByUserId: req.tenantContext?.userId || null,
    rejectedByRole: role,
    rejectedAt: new Date().toISOString(),
    reason,
  };
  createOrUpdateCommand(record);
  return res.json({ ok: true, correlationId, status: record.status });
});

app.get("/api/v1/approvals", requireAuth, extractTenantContext, (req, res) => {
  const role = normalizeRole(req.tenantContext?.role);
  if (!isManagerOrPrincipal(role)) {
    return res.status(403).json({ error: "forbidden", hint: "manager_or_principal_required" });
  }
  const statusFilter = String(req.query.status || "pending").toLowerCase();
  const rows = Array.from(commands.values())
    .filter((c) => Object.keys(REQUEST_TO_COMMAND).includes(String(c.commandType || "")))
    .filter((c) => statusFilter === "all" ? true : String(c.status || "").toLowerCase() === "pending_manager_approval")
    .filter((c) => {
      const dealerOk = !req.tenantContext?.dealerId || !c.tenantContext?.dealerId || c.tenantContext.dealerId === req.tenantContext.dealerId;
      const branchOk = !req.tenantContext?.branchId || !c.tenantContext?.branchId || c.tenantContext.branchId === req.tenantContext.branchId;
      return dealerOk && branchOk;
    })
    .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")))
    .map((c) => ({
      correlationId: c.correlationId,
      status: c.status,
      commandType: c.commandType,
      requestedCommandType: REQUEST_TO_COMMAND[c.commandType] || null,
      createdAt: c.createdAt,
      payload: c.payload,
      tenantContext: c.tenantContext || null,
      error: c.error || null,
    }));
  return res.json({ approvals: rows, count: rows.length });
});

app.post("/api/v1/approvals/:correlationId/approve", requireAuth, extractTenantContext, async (req, res) => {
  const role = normalizeRole(req.tenantContext?.role);
  if (!isManagerOrPrincipal(role)) {
    return res.status(403).json({ error: "forbidden", hint: "manager_or_principal_required" });
  }
  const correlationId = String(req.params.correlationId || "").trim();
  const record = commands.get(correlationId);
  if (!record) return res.status(404).json({ error: "not_found" });
  if (!REQUEST_TO_COMMAND[record.commandType]) {
    return res.status(400).json({ error: "not_approval_request" });
  }
  if (record.status !== "pending_manager_approval") {
    return res.status(409).json({ error: "not_pending", status: record.status });
  }
  const targetType = REQUEST_TO_COMMAND[record.commandType];
  try {
    record.status = "processing";
    record.updatedAt = new Date().toISOString();
    createOrUpdateCommand(record);
    const result = await processCommand(targetType, {
      ...(record.payload || {}),
      _tenantContext: record.tenantContext || null,
      _approval: {
        approvedByUserId: req.tenantContext?.userId || null,
        approvedByRole: role,
        approvedAt: new Date().toISOString(),
      },
    });
    record.status = "done";
    record.updatedAt = new Date().toISOString();
    record.result = {
      approved: true,
      approvedByUserId: req.tenantContext?.userId || null,
      approvedByRole: role,
      executedCommandType: targetType,
      output: result,
    };
    record.error = null;
    createOrUpdateCommand(record);
    return res.json({ ok: true, correlationId, status: record.status, result: record.result });
  } catch (e) {
    record.status = "failed";
    record.updatedAt = new Date().toISOString();
    record.error = e?.message || String(e);
    createOrUpdateCommand(record);
    return res.status(500).json({ error: "approval_execution_failed", detail: record.error });
  }
});

app.post("/api/v1/approvals/:correlationId/reject", requireAuth, extractTenantContext, (req, res) => {
  const role = normalizeRole(req.tenantContext?.role);
  if (!isManagerOrPrincipal(role)) {
    return res.status(403).json({ error: "forbidden", hint: "manager_or_principal_required" });
  }
  const correlationId = String(req.params.correlationId || "").trim();
  const record = commands.get(correlationId);
  if (!record) return res.status(404).json({ error: "not_found" });
  if (!REQUEST_TO_COMMAND[record.commandType]) {
    return res.status(400).json({ error: "not_approval_request" });
  }
  if (record.status !== "pending_manager_approval") {
    return res.status(409).json({ error: "not_pending", status: record.status });
  }
  const reason = String(req.body?.reason || "Rejected by manager").trim();
  record.status = "rejected";
  record.updatedAt = new Date().toISOString();
  record.error = reason;
  record.result = {
    approved: false,
    rejectedByUserId: req.tenantContext?.userId || null,
    rejectedByRole: role,
    rejectedAt: new Date().toISOString(),
    reason,
  };
  createOrUpdateCommand(record);
  return res.json({ ok: true, correlationId, status: record.status });
});

app.post("/api/v1/commands", requireAuth, extractTenantContext, async (req, res) => {
  const normalized = normalizeCommandBody(req.body);
  if (normalized?.error) {
    return res.status(400).json({ error: normalized.error });
  }

  const { commandType, correlationId, payload, meta } = normalized;
  const role = normalizeRole(req.tenantContext?.role);
  if (!canSubmitCommand(role, commandType)) {
    return res.status(403).json({ error: "forbidden", hint: `role ${role} cannot submit ${commandType}` });
  }
  if (requiresManagerApproval(role, commandType)) {
    const requestType = `${commandType}_REQUEST`;
    const pendingRecord = {
      correlationId,
      status: "pending_manager_approval",
      commandType: requestType,
      payload,
      meta: { ...meta, requestId: req.requestId },
      tenantContext: req.tenantContext,
      idempotencyKey: null,
      attempts: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      result: null,
      error: null,
    };
    createOrUpdateCommand(pendingRecord);
    return res.status(202).json({
      correlationId,
      status: pendingRecord.status,
      commandType: pendingRecord.commandType,
      hint: "Awaiting manager approval",
    });
  }
  const idempotencyKey = String(req.headers["idempotency-key"] || meta?.idempotencyKey || "").trim();

  if (commandType === "CREATE_LEAD" && idempotencyKey && idempotencyIndex.has(idempotencyKey)) {
    const existingCorrelationId = idempotencyIndex.get(idempotencyKey);
    const existing = existingCorrelationId ? commands.get(existingCorrelationId) : null;
    if (existing) {
      return res.status(200).json({
        correlationId: existing.correlationId,
        status: existing.status,
        commandType: existing.commandType,
        deduplicated: true,
      });
    }
  }

  // Fast path for live valuation UX: process Tru-Trade report immediately.
  if (commandType === "TRUTRADE_REPORT") {
    try {
      const result = await processCommand(commandType, { ...payload, _tenantContext: req.tenantContext || null });
      return res.status(200).json({
        correlationId,
        status: "done",
        commandType,
        result,
      });
    } catch (e) {
      const mapped = mapTruTradeError(e);
      return res.status(mapped.httpStatus).json({
        correlationId,
        status: "failed",
        commandType,
        error: mapped.error,
        userMessage: mapped.userMessage,
        hint: mapped.hint || null,
        suggestions: mapped.suggestions || null,
      });
    }
  }

  const record = {
    correlationId,
    status: "queued",
    commandType,
    payload,
    meta: { ...meta, requestId: req.requestId },
    tenantContext: req.tenantContext,
    idempotencyKey: commandType === "CREATE_LEAD" && idempotencyKey ? idempotencyKey : null,
    attempts: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    result: null,
    error: null,
  };

  createOrUpdateCommand(record);

  // Simulate async processing.
  (async () => {
    let lastErr = null;
    for (let attempt = 1; attempt <= COMMAND_MAX_RETRIES; attempt++) {
      try {
        record.status = "processing";
        record.attempts = attempt;
        record.updatedAt = new Date().toISOString();
        createOrUpdateCommand(record);

        const result = await processCommand(commandType, { ...payload, _tenantContext: record.tenantContext || null });

        record.status = "done";
        record.updatedAt = new Date().toISOString();
        record.result = result;
        createOrUpdateCommand(record);
        log("info", "command_completed", {
          correlationId: record.correlationId,
          commandType: record.commandType,
          mode: result?.mode ?? null,
          leadId: result?.leadId ?? null,
          stockUnitId: result?.stockUnitId ?? null,
          warning: result?.warning ?? null,
        });
        return;
      } catch (e) {
        lastErr = e;
        record.error = e?.message || String(e);
        record.updatedAt = new Date().toISOString();
        createOrUpdateCommand(record);
        log("warn", "command_attempt_failed", {
          correlationId: record.correlationId,
          commandType: record.commandType,
          attempt,
          maxRetries: COMMAND_MAX_RETRIES,
          error: record.error,
        });
        if (attempt < COMMAND_MAX_RETRIES) {
          await safeSleep(COMMAND_RETRY_DELAY_MS * attempt);
        }
      }
    }
    record.status = "failed";
    record.updatedAt = new Date().toISOString();
    record.error = (lastErr && (lastErr.message || String(lastErr))) || "Unknown command failure";
    createOrUpdateCommand(record);
    pushDeadLetter(record, record.error);
  })();

  return res.status(202).json({
    correlationId,
    status: record.status,
    commandType,
  });
});

app.get("/api/v1/commands/:correlationId", requireAuth, (req, res) => {
  const correlationId = req.params.correlationId;
  const record = commands.get(correlationId);
  if (!record) return res.status(404).json({ error: "not_found" });
  return res.json({
    correlationId: record.correlationId,
    status: record.status,
    commandType: record.commandType,
    result: record.result,
    tenantContext: record.tenantContext || null,
    error: record.error,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt
  });
});

/**
 * Webhook placeholders (integration direction: systems -> our connector).
 * In v1 these just acknowledge receipt.
 */
app.post("/api/v1/webhooks/:type", requireAuth, (req, res) => {
  const type = req.params.type;
  // TODO: validate webhook signatures per vendor.
  return res.status(200).json({ ok: true, receivedType: type });
});

// Bind all interfaces so phones on the same LAN can reach this PC (not just localhost).
app.listen(PORT, "0.0.0.0", () => {
  loadStore();
  log("info", "connector_started", {
    port: PORT,
    bind: "0.0.0.0",
    commandsLoaded: commands.size,
    deadLetters: deadLetters.length,
    storeFile: STORE_FILE,
  });
});

